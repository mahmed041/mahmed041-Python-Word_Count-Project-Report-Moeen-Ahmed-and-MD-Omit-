import threading
import time
import queue

start_time = time.time()

# list of characters to remove from text file
remove = [',', '\'', '-', ';', ':', '.', '(', ')', '$', '“', '_', '”', '=']


# count_words function returns list of words and their recurring frequency
def count_words(words):
    # create an empty dictionary to store the word counts
    word_counts = {}

    # iterate through the list of words
    for word in words:
        # if the word is not already in the dictionary, add it with a count of 1
        if word not in word_counts:
            word_counts[word] = 1
        # if the word is already in the dictionary, increment its count
        else:
            word_counts[word] += 1

    sorted_word_counts = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
    # iterate through the word counts dictionary
    for word, count in sorted_word_counts:
        # output each word and its count on a new line
        print(f"{word}: {count}")


# function to remove characters from text file
def remove_chars(s, chars):
    # create a new empty string to store the result
    result = ""

    # iterate through each character in the input string
    for c in s:
        # if the character is not in the list of characters to remove,
        # append it to the result string
        if c not in chars:
            result += c

    # return the resulting string
    return result


# function to process the text file and return a list of modified words
def process_text_file(q):
    with open('filename.txt', encoding='utf8') as file:
        contents = file.read()  # Read the contents of the file
        words = [word.lower() for word in contents.split()]
        modified_words = [remove_chars(word, remove) for word in words]
        q.put(modified_words)


# create a queue to store the result of the process_text_file function
q = queue.Queue()

# create a thread to process the text file
thread1 = threading.Thread(target=process_text_file, args=(q,))

# start the thread
thread1.start()

# wait for the thread to finish
thread1.join()

# retrieve the result from the queue
modified_words = q.get()

# create a thread to count the words
thread2 = threading.Thread(target=count_words, args=(modified_words,))

# start the thread
thread2.start()

# wait for the thread to finish
thread2.join()

print('\n______________________________________________')
print("Program run for: ", time.time() - start_time)
print('______________________________________________')
