import time
from mpi4py import MPI

start_time = time.time()

# list of characters to remove from text file
remove = [',', ',', '\'', '-', ';', ':', '.', '(', ')', '$', '“', '_', '”', '=']


# count_words_mpi function returns list of words and their recurring frequency
def count_words_mpi():
    # Get the rank and size of the current process
    rank = MPI.COMM_WORLD.rank
    size = MPI.COMM_WORLD.size

    # Split the list of words into chunks and distribute them to different processes
    chunk_size = len(words) // size
    local_words = words[rank * chunk_size:(rank + 1) * chunk_size]

    # Create an empty dictionary to store the word counts
    local_word_counts = {}

    # Iterate through the list of words
    for word in local_words:
        # If the word is not already in the dictionary, add it with a count of 1
        if word not in local_word_counts:
            local_word_counts[word] = 1
        # If the word is already in the dictionary, increment its count
        else:
            local_word_counts[word] += 1

    # Reduce the local word counts to the root process
    global_word_counts = MPI.COMM_WORLD.reduce(local_word_counts, op=MPI.SUM, root=0)

    # If the current process is the root process, sort the global word counts and print them
    if rank == 0:
        sorted_word_counts = sorted(global_word_counts.items(), key=lambda x: x[1], reverse=True)
        for word, count in sorted_word_counts:
            print(f"{word}: {count}")


# function to remove characters from text file
def remove_chars(s, chars):
    # create a new empty string to store the result
    result = ""

    # iterate through each character in the input string
    for c in s:
        # if the character is not in the list of characters to remove,
        # append it to the result string
        if c not in chars:
            result += c

    # return the resulting string
    return result


with open('filename.txt', encoding='utf8') as file:
    contents = file.read()  # Read the contents of the file
    words = [word.lower() for word in contents.split()]
    modified_words = [remove_chars(word, remove) for word in words]

    print(count_words_mpi())

print('\n______________________________________________')
print("Program run for: ", time.time() - start_time)
print('______________________________________________')
